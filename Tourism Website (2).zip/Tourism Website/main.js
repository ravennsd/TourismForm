
  
 let email= document.getElementById("email");
 let pwd= document.getElementById("pwd");


 function validate()
 {
   if((email.value=="")||(pwd.value=="")){
     alert("Fields cannot be empty");
     return false;
   }

   else
   {
    // document.write("Awesome");
    return true;
   }

 }
