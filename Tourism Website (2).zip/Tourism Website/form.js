
const form=document.querySelector("#formId");

form.addEventListener("submit", validate);
form.addEventListener("submit", passvalidate);
form.addEventListener("submit", checkemail);
form.addEventListener("submit", checkpwd);

let email=document.getElementById("email");
let name=document.querySelector("#name");
let pwd=document.querySelector("#pwd");
let dob=document.getElementById("date");

function checkemail()
{
  let regex=/^([\w\.\-]+)@([\w\-]+)\.([a-z]{2,3})(\.[a-z]{2,3}?)$/
    return regex.test(str);

    
}

function checkpwd()
{
    let regex=/^([\w\]+)$/
    return regex.test(str);

    
}

function validate()
{
    
    if(email.value==""||name.value==""||dob.value=="")
    {
        alert("Fields Cannot Be Empty");
        return false;
    }

    if(!checkemail(form.email.value))
    {
        alert("Email Invalid")
    
     return false;
    }
    
    else{
        return true;
    }


}
function passvalidate()
{
    if(!checkpwd(form.email.value))
    {
        alert("password entered is not valid")

        return false;
    }
    if(pwd.value=="")
    {
        alert("You must set a Password");
        return false;
    }
      else if(pwd.value.length<8)
    {
        alert("Password needs to be at least 8 characters long");
        return false;
    }
    else
    {
        return true;
    }
    
}



